package com.r0adkll.slidr.model;


public interface SlidrInterface {

    void lock();
    void unlock();
}
