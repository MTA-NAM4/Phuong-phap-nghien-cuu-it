package com.r0adkll.slidr.model;


public enum SlidrPosition {

    LEFT,
    RIGHT,
    TOP,
    BOTTOM,
    VERTICAL,
    HORIZONTAL
}
